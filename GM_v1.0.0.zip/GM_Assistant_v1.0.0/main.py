# main entry point
print('GM Assistant çalışıyor')